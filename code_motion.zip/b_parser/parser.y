%{
#include <stdio.h>
int yylex();
void yyerror(char *s);
extern int yylineno;
extern FILE *yyin;
%}

%token WHILE ID NUM RELOP

%left RELOP
%left '+' '-'
%left '*' '/'

%%

stmts   : stmts stmt
        |
        ;

stmt    : ID '=' expr ';'
        | WHILE '(' expr ')' stmt
        | '{' stmts '}'
        ;

expr    : expr '+' expr
        | expr '-' expr
        | expr '*' expr
        | expr '/' expr
        | expr RELOP expr
        | '(' expr ')'
        | ID
        | NUM
        ;

%%

void yyerror(char *s)
{
    printf("Syntax error at line %d\n", yylineno);
}

int main(int argc, char *argv[])
{
    if (argc > 1)
        yyin = fopen(argv[1], "r");
    if (yyparse() == 0)
        printf("Syntactically correct\n");
    return 0;
}
