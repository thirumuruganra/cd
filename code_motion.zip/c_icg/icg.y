%{
#include <stdio.h>
#include <string.h>
int yylex();
void yyerror(char *s);
extern FILE *yyin;

int tempCount = 0;      /* t1, t2, t3 ...  */
int labelCount = 0;     /* L1, L2, L3 ...  */
int stack[50];          /* labels waiting to be printed */
int top = -1;

void gen(char *res, char *a, char *op, char *b);
int  newLabel();
void push(int l);
int  pop();
%}

%union {
    char s[20];
}

%token <s> ID NUM RELOP
%token WHILE
%type  <s> expr

%left RELOP
%left '+' '-'
%left '*' '/'

%%

stmts   : stmts stmt
        |
        ;

stmt    : ID '=' expr ';'               { printf("%s = %s\n", $1, $3); }
        | WHILE                         { int l = newLabel();
                                          printf("L%d:\n", l);
                                          push(l); }
          '(' expr ')'                  { int l = newLabel();
                                          printf("ifFalse %s goto L%d\n", $4, l);
                                          push(l); }
          stmt                          { int end = pop();
                                          int start = pop();
                                          printf("goto L%d\n", start);
                                          printf("L%d:\n", end); }
        | '{' stmts '}'
        ;

expr    : expr '+' expr                 { gen($$, $1, "+", $3); }
        | expr '-' expr                 { gen($$, $1, "-", $3); }
        | expr '*' expr                 { gen($$, $1, "*", $3); }
        | expr '/' expr                 { gen($$, $1, "/", $3); }
        | expr RELOP expr               { gen($$, $1, $2, $3); }
        | '(' expr ')'                  { strcpy($$, $2); }
        | ID                            { strcpy($$, $1); }
        | NUM                           { strcpy($$, $1); }
        ;

%%

/* make a new temp, store its name in res, print:  res = a op b */
void gen(char *res, char *a, char *op, char *b)
{
    sprintf(res, "t%d", ++tempCount);
    printf("%s = %s %s %s\n", res, a, op, b);
}

int newLabel()
{
    return ++labelCount;
}

void push(int l)
{
    stack[++top] = l;
}

int pop()
{
    return stack[top--];
}

void yyerror(char *s)
{
    printf("Syntax error\n");
}

int main(int argc, char *argv[])
{
    if (argc > 1)
        yyin = fopen(argv[1], "r");
    yyparse();
    return 0;
}
