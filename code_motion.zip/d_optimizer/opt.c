#include <stdio.h>
#include <string.h>
#include <ctype.h>

char code[100][60];         /* code[i] = line i of the three-address code, e.g. "t1 = n * 4" */
int  n = 0;

#define is(s, t) (strcmp(s, t) == 0)

/* is the line "x = ..." ?  (copies x out) */
int assign(char *line, char *x)
{
    char eq[20];
    return sscanf(line, "%s %s", x, eq) == 2 && is(eq, "=");
}

/* does the line use the word v?  (word 0 is the target, so it is not a use) */
int uses(char *line, char *v)
{
    char tmp[60], *w;
    int k = 0;
    strcpy(tmp, line);
    for (w = strtok(tmp, " "); w; w = strtok(0, " "), k++)
        if (k > 0 && is(w, v)) return 1;
    return 0;
}

/* number of lines s..e that assign to x;  *d = the last of them */
int defs(char *x, int s, int e, int *d)
{
    char t[20];
    int k, c = 0;
    for (k = s; k <= e; k++)
        if (assign(code[k], t) && is(t, x)) { c++; *d = k; }
    return c;
}

/* loop invariant operand: a constant, or not changed in the loop, or set once by an invariant line */
int invariant(char *w, int s, int e, int inv[])
{
    int d, c;
    if (isdigit(*w)) return 1;
    c = defs(w, s, e, &d);
    return c == 0 || (c == 1 && inv[d]);
}

/* code motion: move loop invariant lines in front of the loop */
void optimize()
{
    char x[30], a[20], op[20], b[20], lab[20], tmp[100][60];
    int inv[100] = {0}, s, e, i, k, m, d, changed, cnt;

    /* find the loop: "goto Lk" in line e jumps back to the label "Lk:" in line s */
    for (e = 0; e < n; e++)
        if (sscanf(code[e], "goto %s", lab) == 1) {
            sprintf(x, "%s:", lab);
            for (s = 0; s < e && !is(code[s], x); s++) ;
            if (s < e) break;
        }
    if (e == n) return;                                         /* no loop */

    /* mark the invariant lines  (x = a  or  x = a op b), repeat until nothing new is marked */
    do {
        changed = 0;
        for (i = s; i <= e; i++) {
            m = sscanf(code[i], "%s = %s %s %s", x, a, op, b);
            if (inv[i] || (m != 2 && m != 4)) continue;
            if (m == 4 && !strchr("+-*/", op[0])) continue;     /* comparison stays in the loop */
            if (!invariant(a, s, e, inv) || (m == 4 && !invariant(b, s, e, inv))) continue;
            if (defs(x, s, e, &d) != 1) continue;               /* x is set more than once in the loop */
            for (k = s; k < i; k++)
                if (uses(code[k], x)) break;                    /* x is used before this line */
            if (k < i) continue;
            inv[i] = 1;
            changed = 1;
        }
    } while (changed);

    /* new order:  before the loop, invariant lines, rest of the loop, after the loop */
    cnt = 0;
    for (i = 0; i < s; i++)
        strcpy(tmp[cnt++], code[i]);
    for (i = s; i <= e; i++)
        if (inv[i]) strcpy(tmp[cnt++], code[i]);
    for (i = s; i <= e; i++)
        if (!inv[i]) strcpy(tmp[cnt++], code[i]);
    for (i = e + 1; i < n; i++)
        strcpy(tmp[cnt++], code[i]);
    for (i = 0; i < n; i++)
        strcpy(code[i], tmp[i]);
}

int main(int argc, char *argv[])
{
    FILE *fp = argc > 1 ? fopen(argv[1], "r") : stdin;
    int i;

    if (!fp) return printf("Cannot open file\n");
    while (fgets(code[n], 60, fp)) {                    /* one line per row */
        code[n][strcspn(code[n], "\r\n")] = 0;
        if (code[n][0]) n++;                            /* skip empty lines */
    }
    printf("Input code:\n");
    for (i = 0; i < n; i++)
        printf("%s\n", code[i]);
    optimize();
    printf("\nOptimized code:\n");
    for (i = 0; i < n; i++)
        printf("%s\n", code[i]);
    return 0;
}
