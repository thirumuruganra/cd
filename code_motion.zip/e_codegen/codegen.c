#include <stdio.h>
#include <string.h>
#include <ctype.h>

char code[100][60];         /* code[i] = line i of the three-address code, e.g. "t1 = n * 4" */
int  n = 0;
char names[50][20];         /* names[k] lives in register Rk */
int  nreg = 0;

#define is(s, t) (strcmp(s, t) == 0)

/* operator table:  op, instruction (or jump if TRUE), jump if FALSE */
char *tab[][3] = {
    {"+", "ADD"}, {"-", "SUB"}, {"*", "MUL"}, {"/", "DIV"},
    {"<", "JL", "JGE"}, {"<=", "JLE", "JG"}, {">", "JG", "JLE"},
    {">=", "JGE", "JL"}, {"==", "JE", "JNE"}, {"!=", "JNE", "JE"},
};

/* column col of the table row for op;  col 2 is 0 for the arithmetic operators */
char *get(char *op, int col)
{
    int k;
    for (k = 0; k < 10; k++)
        if (is(tab[k][0], op)) return tab[k][col];
    return 0;
}

/* register number of a variable / temp (a new one the first time) */
int R(char *name)
{
    int k;
    for (k = 0; k < nreg; k++)
        if (is(names[k], name)) return k;
    strcpy(names[nreg], name);
    return nreg++;
}

/* operand: constant -> #5, variable -> R2 */
void src(char *x)
{
    if (isdigit(*x)) printf("#%s", x); else printf("R%d", R(x));
}

void codegen()
{
    char w[5][20], y[20], z[20];
    int i, m, k;

    for (i = 0; i < n; i++) {
        m = sscanf(code[i], "%s %s %s %s %s", w[0], w[1], w[2], w[3], w[4]);   /* m = number of words */

        if (strchr(w[0], ':'))                                  /* L1: */
            printf("%s\n", w[0]);
        else if (is(w[0], "goto"))                              /* goto L1 */
            printf("JMP %s\n", w[1]);
        else if (m == 3) {                                      /* x = y */
            printf("MOV R%d, ", R(w[0])); src(w[2]); printf("\n");
        }
        else if (get(w[3], 2)) {                                /* t1 = a < b ; ifFalse t1 goto L  ->  CMP, opposite jump */
            sscanf(code[++i], "ifFalse %s goto %s", y, z);
            printf("CMP "); src(w[2]); printf(", "); src(w[4]); printf("\n");
            printf("%s %s\n", get(w[3], 2), z);
        }
        else {                                                  /* x = a op b */
            printf("MOV R%d, ", R(w[0])); src(w[2]);
            printf("\n%s R%d, ", get(w[3], 1), R(w[0])); src(w[4]); printf("\n");
        }
    }

    printf("\n----- Register allocation -----\n");
    for (k = 0; k < nreg; k++)
        printf("R%d = %s\n", k, names[k]);
}

int main(int argc, char *argv[])
{
    FILE *fp = argc > 1 ? fopen(argv[1], "r") : stdin;

    if (!fp) return printf("Cannot open file\n");
    while (fgets(code[n], 60, fp)) {                    /* one line per row */
        code[n][strcspn(code[n], "\r\n")] = 0;
        if (code[n][0]) n++;                            /* skip empty lines */
    }
    codegen();
    return 0;
}
