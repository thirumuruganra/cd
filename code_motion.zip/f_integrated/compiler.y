%{
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "compiler.h"
int yylex();
void yyerror(char *s);
extern FILE *yyin;
extern int yylineno;

char code[200][60];     /* three-address code, one line per row */
int  n = 0;

int tempCount = 0;      /* t1, t2, t3 ...  */
int labelCount = 0;     /* L1, L2, L3 ...  */
int stack[50];          /* labels waiting to be printed */
int top = -1;

void emit(char *fmt, ...);
void gen(char *res, char *a, char *op, char *b);
int  newLabel();
void push(int l);
int  pop();
%}

%union {
    char s[20];
}

%token <s> ID NUM RELOP
%token WHILE
%type  <s> expr

%left RELOP
%left '+' '-'
%left '*' '/'

%%

stmts   : stmts stmt
        |
        ;

stmt    : ID '=' expr ';'               { emit("%s = %s", $1, $3); }
        | WHILE                         { int l = newLabel();
                                          emit("L%d:", l);
                                          push(l); }
          '(' expr ')'                  { int l = newLabel();
                                          emit("ifFalse %s goto L%d", $4, l);
                                          push(l); }
          stmt                          { int end = pop();
                                          int start = pop();
                                          emit("goto L%d", start);
                                          emit("L%d:", end); }
        | '{' stmts '}'
        ;

expr    : expr '+' expr                 { gen($$, $1, "+", $3); }
        | expr '-' expr                 { gen($$, $1, "-", $3); }
        | expr '*' expr                 { gen($$, $1, "*", $3); }
        | expr '/' expr                 { gen($$, $1, "/", $3); }
        | expr RELOP expr               { gen($$, $1, $2, $3); }
        | '(' expr ')'                  { strcpy($$, $2); }
        | ID                            { strcpy($$, $1); }
        | NUM                           { strcpy($$, $1); }
        ;

%%

/* store one line of three-address code (used like printf) */
void emit(char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    vsprintf(code[n++], fmt, args);
    va_end(args);
}

/* make a new temp, store its name in res, emit:  res = a op b */
void gen(char *res, char *a, char *op, char *b)
{
    sprintf(res, "t%d", ++tempCount);
    emit("%s = %s %s %s", res, a, op, b);
}

int newLabel()
{
    return ++labelCount;
}

void push(int l)
{
    stack[++top] = l;
}

int pop()
{
    return stack[top--];
}

void yyerror(char *s)
{
    printf("\nSyntax error at line %d\n", yylineno);
}

int main(int argc, char *argv[])
{
    int i;

    if (argc > 1) {
        yyin = fopen(argv[1], "r");
        if (yyin == NULL) {
            printf("Cannot open file %s\n", argv[1]);
            return 1;
        }
    }

    printf("========== 1. LEXICAL ANALYSIS ==========\n");
    if (yyparse() != 0)
        return 1;

    printf("\n========== 2. SYNTAX ANALYSIS ==========\n");
    printf("Syntactically correct\n");

    printf("\n========== 3. INTERMEDIATE CODE ==========\n");
    for (i = 0; i < n; i++)
        printf("%s\n", code[i]);

    printf("\n========== 4. CODE OPTIMIZATION (code motion) ==========\n");
    optimize();
    for (i = 0; i < n; i++)
        printf("%s\n", code[i]);

    printf("\n========== 5. CODE GENERATION ==========\n");
    codegen();
    return 0;
}
