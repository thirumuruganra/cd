#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "compiler.h"

#define is(s, t) (strcmp(s, t) == 0)

int isTemp(char *s) { return s[0] == 't' && isdigit(s[1]); }

/* is the line "x = ..." ?  (copies x out) */
int assign(char *line, char *x)
{
    char eq[20];
    return sscanf(line, "%s %s", x, eq) == 2 && is(eq, "=");
}

/* remove line i */
void del(int i)
{
    for (; i < n - 1; i++)
        strcpy(code[i], code[i + 1]);
    n--;
}

/* replace the word 'old' by 'new' in lines from..n-1 */
void replace(char *old, char *new, int from)
{
    char tmp[60], *w;
    int k;
    for (k = from; k < n; k++) {
        strcpy(tmp, code[k]);
        code[k][0] = 0;
        for (w = strtok(tmp, " "); w; w = strtok(0, " ")) {
            if (code[k][0]) strcat(code[k], " ");
            strcat(code[k], is(w, old) ? new : w);
        }
    }
}


/* p to the power q (both whole numbers) */
int power(int p, int q)
{
    int r = 1;
    while (q-- > 0) r *= p;
    return r;
}

/* does the line use the word v?  (word 0 is the target, so it is not a use) */
int uses(char *line, char *v)
{
    char tmp[60], *w;
    int k = 0;
    strcpy(tmp, line);
    for (w = strtok(tmp, " "); w; w = strtok(0, " "), k++)
        if (k > 0 && is(w, v)) return 1;
    return 0;
}

/* number of lines s..e that assign to x;  *d = the last of them */
int defs(char *x, int s, int e, int *d)
{
    char t[20];
    int k, c = 0;
    for (k = s; k <= e; k++)
        if (assign(code[k], t) && is(t, x)) { c++; *d = k; }
    return c;
}

/* loop invariant operand: a constant, or not changed in the loop, or set once by an invariant line */
int invariant(char *w, int s, int e, int inv[])
{
    int d, c;
    if (isdigit(*w)) return 1;
    c = defs(w, s, e, &d);
    return c == 0 || (c == 1 && inv[d]);
}

/* line "goto Lk": the number of the line "Lk:" (-1 if line i is not a goto) */
int target(int i)
{
    char lab[20], x[22];
    int k;
    if (sscanf(code[i], "goto %s", lab) != 1) return -1;
    sprintf(x, "%s:", lab);
    for (k = 0; k < n && !is(code[k], x); k++) ;
    return k < n ? k : -1;
}

/* code motion for the loop in lines s..e: move the invariant lines in front of line s.  Returns how many were moved */
int moveInvariant(int s, int e)
{
    char x[30], a[20], op[20], b[20], tmp[200][60];
    int inv[200] = {0}, i, k, m, d, changed, cnt = 0;

    /* mark the invariant lines  (x = a  or  x = a op b), repeat until nothing new is marked */
    do {
        changed = 0;
        for (i = s; i <= e; i++) {
            m = sscanf(code[i], "%s = %s %s %s", x, a, op, b);
            if (inv[i] || (m != 2 && m != 4)) continue;
            if (m == 4 && !strchr("+-*/%^", op[0])) continue;   /* comparison stays in the loop */
            if (!invariant(a, s, e, inv) || (m == 4 && !invariant(b, s, e, inv))) continue;
            if (defs(x, s, e, &d) != 1) continue;               /* x is set more than once in the loop */
            for (k = s; k < i; k++)
                if (uses(code[k], x)) break;                    /* x is used before this line */
            if (k < i) continue;
            inv[i] = 1;
            changed = 1;
        }
    } while (changed);

    /* new order:  before the loop, invariant lines, rest of the loop, after the loop */
    for (i = 0; i < s; i++)
        strcpy(tmp[cnt++], code[i]);
    for (i = s; i <= e; i++)
        if (inv[i]) strcpy(tmp[cnt++], code[i]);
    m = cnt - s;
    for (i = s; i <= e; i++)
        if (!inv[i]) strcpy(tmp[cnt++], code[i]);
    for (i = e + 1; i < n; i++)
        strcpy(tmp[cnt++], code[i]);
    for (i = 0; i < n; i++)
        strcpy(code[i], tmp[i]);
    return m;
}

/* find every loop (a label that a later "goto" jumps back to) and do code motion on it */
void codeMotion()
{
    int s, e, i, j;

    for (s = 0; s < n; s++) {
        e = -1;
        for (i = s + 1; i < n; i++)
            if (target(i) == s) e = i;                          /* last jump back to line s */
        if (e < 0) continue;                                    /* line s is not a loop start */

        /* a for loop: "goto body" jumps over the step part, and the body ends with a jump back to the step */
        for (i = s; i <= e; i++)
            if (target(i) > e) {
                for (j = target(i); j < n && !(target(j) >= s && target(j) < target(i)); j++) ;
                if (j < n) e = j;
            }
        s += moveInvariant(s, e);                               /* s is now the loop start again */
    }
}

void optimize()
{
    char x[20], a[20], op[20], b[20], t[20], a2[20], op2[20], b2[20], *why;
    int i, j, p, q, copy, gone;

    for (i = 0; i < n; i++) {
        if (sscanf(code[i], "%s = %s %s %s", x, a, op, b) != 4) continue;    /* only  x = a op b */
        why = 0; copy = 0; gone = 0;

        /* strength reduction */
        if ((is(op, "^") || is(op, "**")) && is(b, "2"))     { strcpy(op, "*"); strcpy(b, a); why = "strength reduction"; }
        else if (is(op, "*") && is(b, "2")) { strcpy(op, "+"); strcpy(b, a); why = "strength reduction"; }

        /* constant folding */
        if (isdigit(*a) && isdigit(*b) && !op[1] && strchr("+-*/%^", *op) && (atoi(b) || !strchr("/%", *op))) {
            p = atoi(a); q = atoi(b);
            sprintf(a, "%d", *op == '+' ? p + q : *op == '-' ? p - q : *op == '*' ? p * q :
                             *op == '/' ? p / q : *op == '%' ? p % q : power(p, q));
            copy = 1; why = "constant folding";
        }
        /* algebraic identities: the line becomes  x = a  */
        else if ((is(op, "+") || is(op, "-")) && is(b, "0"))        copy = 1;
        else if (is(op, "+") && is(a, "0"))                         { strcpy(a, b); copy = 1; }
        else if ((is(op, "*") || is(op, "/")) && is(b, "1"))        copy = 1;
        else if (is(op, "*") && is(a, "1"))                         { strcpy(a, b); copy = 1; }
        else if (is(op, "*") && (is(a, "0") || is(b, "0")))         { strcpy(a, "0"); copy = 1; }
        if (copy && !why) why = "algebraic identity";

        /* dead code: x = x */
        if (copy && is(x, a)) {
            del(i--);
            continue;
        }

        /* common subexpression: same "a op b" earlier in this block (walk back up to the label/goto/if) */
        if (!copy)
            for (j = i - 1; j >= 0 && assign(code[j], t); j--) {
                if (is(t, a) || is(t, b)) break;                         /* an operand was changed: stop */
                if (isTemp(t) && sscanf(code[j], "%*s = %s %s %s", a2, op2, b2) == 3 &&
                    is(a, a2) && is(op, op2) && is(b, b2)) {
                    if (isTemp(x)) gone = 1;                             /* temp: delete line, reuse old temp */
                    else { strcpy(a, t); copy = 1; why = "common subexpression"; }
                    break;
                }
            }
        if (gone) {
            replace(x, t, i + 1);
            del(i--);
            continue;
        }

        if (why) {                                                       /* write the changed line back */
            if (copy) sprintf(code[i], "%s = %s", x, a);
            else      sprintf(code[i], "%s = %s %s %s", x, a, op, b);
        }
    }

    /* dead code: lines after a goto, up to the next label, can never run */
    for (i = 0; i < n; i++)
        if (!strncmp(code[i], "goto", 4))
            while (i + 1 < n && !strchr(code[i + 1], ':')) {
                del(i + 1);
            }

    codeMotion();                                                        /* loop invariant lines move out of loops */

    for (i = 0; i < n; i++)
        puts(code[i]);
}
