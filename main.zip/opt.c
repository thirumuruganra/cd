#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "compiler.h"

#define is(s, t) (strcmp(s, t) == 0)

int isTemp(char *s) { return s[0] == 't' && isdigit(s[1]); }

/* is the line "x = ..." ?  (copies x out) */
int assign(char *line, char *x)
{
    char eq[20];
    return sscanf(line, "%s %s", x, eq) == 2 && is(eq, "=");
}

/* remove line i */
void del(int i)
{
    for (; i < n - 1; i++)
        strcpy(code[i], code[i + 1]);
    n--;
}

/* replace the word 'old' by 'new' in lines from..n-1 */
void replace(char *old, char *new, int from)
{
    char tmp[60], *w;
    int k;
    for (k = from; k < n; k++) {
        strcpy(tmp, code[k]);
        code[k][0] = 0;
        for (w = strtok(tmp, " "); w; w = strtok(0, " ")) {
            if (code[k][0]) strcat(code[k], " ");
            strcat(code[k], is(w, old) ? new : w);
        }
    }
}


void optimize()
{
    char x[20], a[20], op[20], b[20], t[20], a2[20], op2[20], b2[20], *why;
    int i, j, p, q, copy, gone;

    for (i = 0; i < n; i++) {
        if (sscanf(code[i], "%s = %s %s %s", x, a, op, b) != 4) continue;    /* only  x = a op b */
        why = 0; copy = 0; gone = 0;

        /* strength reduction */
        if (is(op, "**") && is(b, "2"))     { strcpy(op, "*"); strcpy(b, a); why = "strength reduction"; }
        else if (is(op, "*") && is(b, "2")) { strcpy(op, "+"); strcpy(b, a); why = "strength reduction"; }

        /* constant folding */
        if (isdigit(*a) && isdigit(*b) && !op[1] && strchr("+-*/%", *op) && (atoi(b) || !strchr("/%", *op))) {
            p = atoi(a); q = atoi(b);
            sprintf(a, "%d", *op == '+' ? p + q : *op == '-' ? p - q : *op == '*' ? p * q :
                             *op == '/' ? p / q : p % q);
            copy = 1; why = "constant folding";
        }
        /* algebraic identities: the line becomes  x = a  */
        else if ((is(op, "+") || is(op, "-")) && is(b, "0"))        copy = 1;
        else if (is(op, "+") && is(a, "0"))                         { strcpy(a, b); copy = 1; }
        else if ((is(op, "*") || is(op, "/")) && is(b, "1"))        copy = 1;
        else if (is(op, "*") && is(a, "1"))                         { strcpy(a, b); copy = 1; }
        else if (is(op, "*") && (is(a, "0") || is(b, "0")))         { strcpy(a, "0"); copy = 1; }
        if (copy && !why) why = "algebraic identity";

        /* dead code: x = x */
        if (copy && is(x, a)) {
            del(i--);
            continue;
        }

        /* common subexpression: same "a op b" earlier in this block (walk back up to the label/goto/if) */
        if (!copy)
            for (j = i - 1; j >= 0 && assign(code[j], t); j--) {
                if (is(t, a) || is(t, b)) break;                         /* an operand was changed: stop */
                if (isTemp(t) && sscanf(code[j], "%*s = %s %s %s", a2, op2, b2) == 3 &&
                    is(a, a2) && is(op, op2) && is(b, b2)) {
                    if (isTemp(x)) gone = 1;                             /* temp: delete line, reuse old temp */
                    else { strcpy(a, t); copy = 1; why = "common subexpression"; }
                    break;
                }
            }
        if (gone) {
            replace(x, t, i + 1);
            del(i--);
            continue;
        }

        if (why) {                                                       /* write the changed line back */
            if (copy) sprintf(code[i], "%s = %s", x, a);
            else      sprintf(code[i], "%s = %s %s %s", x, a, op, b);
        }
    }

    /* dead code: lines after a goto, up to the next label, can never run */
    for (i = 0; i < n; i++)
        if (!strncmp(code[i], "goto", 4))
            while (i + 1 < n && !strchr(code[i + 1], ':')) {
                del(i + 1);
            }

    for (i = 0; i < n; i++)
        puts(code[i]);
}
