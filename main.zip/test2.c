int main()
{
    int x = 2 + 3, y, z;
    y = x * 1;
    z = (x + y) * (x + y);
    if (z > 10 && y != 0)
        z = z * 2;
    x = -y;
    return z;
}
