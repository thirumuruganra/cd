#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "compiler.h"

char names[50][20];         /* names[k] lives in register Rk */
int  nreg = 0, labels = 0;

#define is(s, t) (strcmp(s, t) == 0)

/* operator table:  op, instruction (or jump if TRUE), jump if FALSE */
char *tab[][3] = {
    {"+", "ADD"}, {"-", "SUB"}, {"*", "MUL"}, {"/", "DIV"}, {"%", "MOD"}, {"^", "POW"}, {"&&", "AND"}, {"||", "OR"},
    {"<", "JL", "JGE"}, {"<=", "JLE", "JG"}, {">", "JG", "JLE"},
    {">=", "JGE", "JL"}, {"==", "JE", "JNE"}, {"!=", "JNE", "JE"},
};

/* column col of the table row for op;  col 2 is 0 for the arithmetic operators */
char *get(char *op, int col)
{
    int k;
    for (k = 0; k < 14; k++)
        if (is(tab[k][0], op)) return tab[k][col];
    return 0;
}

/* register number of a variable / temp (a new one the first time) */
int R(char *name)
{
    int k;
    for (k = 0; k < nreg; k++)
        if (is(names[k], name)) return k;
    strcpy(names[nreg], name);
    return nreg++;
}

/* operand: constant -> #5, variable -> R2 */
void src(char *x)
{
    if (isdigit(*x)) printf("#%s", x); else printf("R%d", R(x));
}

void cmp(char *a, char *b)
{
    printf("CMP "); src(a); printf(", "); src(b); printf("\n");
}

void codegen()
{
    char w[6][20], y[20], z[20], u[20], *x, *a, *op, *b;
    int i, m, k;

    for (i = 0; i < n; i++) {
        m = sscanf(code[i], "%s %s %s %s %s %s", w[0], w[1], w[2], w[3], w[4], w[5]);   /* m = number of words */

        if (strchr(w[0], ':'))                                  /* L1: */
            printf("%s\n", w[0]);
        else if (is(w[0], "goto"))                              /* goto L1 */
            printf("JMP %s\n", w[1]);
        else if (is(w[0], "if")) {                              /* if a <= b goto L1 */
            cmp(w[1], w[3]);
            printf("%s %s\n", get(w[2], 1), w[5]);
        }
        else if (is(w[0], "ifFalse")) {                         /* ifFalse t goto L1 */
            cmp(w[1], "0");
            printf("JE %s\n", w[3]);
        }
        else if (is(w[0], "return")) {                          /* return x */
            printf("MOV AX, "); src(w[1]); printf("\nRET\n");
        }
        else if (m == 3) {                                      /* x = y */
            printf("MOV R%d, ", R(w[0])); src(w[2]); printf("\n");
        }
        else if (m == 4) {                                      /* x = -y   or   x = !y */
            printf("MOV R%d, ", R(w[0])); src(w[3]);
            printf("\n%s R%d\n", is(w[2], "-") ? "NEG" : "NOT", R(w[0]));
        }
        else if (m == 5) {                                      /* x = a op b */
            x = w[0]; a = w[2]; op = w[3]; b = w[4];

            if (get(op, 2)) {                                   /* relational operator */
                if (i + 1 < n && sscanf(code[i + 1], "ifFalse %s goto %s", y, z) == 2 && is(y, x)) {
                    cmp(a, b);                                  /* t1 = a < b ; ifFalse t1 goto L  ->  CMP, opposite jump */
                    printf("%s %s\n", get(op, 2), z);
                    i++;
                } else {
                    k = ++labels;                               /* x = 1 if true, else 0 */
                    printf("MOV R%d, #1\n", R(x));
                    cmp(a, b);
                    printf("%s X%d\nMOV R%d, #0\nX%d:\n", get(op, 1), k, R(x), k);
                }
            }
            else if (i + 1 < n && sscanf(code[i + 1], "%s = %s %s", y, z, u) == 2 &&
                     is(z, x) && is(y, a) && !isdigit(*a)) {
                printf("%s R%d, ", get(op, 1), R(a));           /* t1 = v + i ; v = t1  ->  ADD Rv, Ri */
                src(b); printf("\n");
                i++;
            }
            else {
                printf("MOV R%d, ", R(x)); src(a);
                printf("\n%s R%d, ", get(op, 1), R(x)); src(b); printf("\n");
            }
        }
    }

    printf("\n----- Register allocation -----\n");
    for (k = 0; k < nreg; k++)
        printf("R%d = %s\n", k, names[k]);
}
