int main() {
    int i, j, s = 0, a = 2, b = 3, c;
    for (i = 0; i < 5; i++) {
        c = a ^ 2 + b;
        for (j = 0; j < 3; j++)
            s = s + c * i + a * b;
    }
    return s;
}
