int main() {
    int i, s = 0;
    for (i = 0; i < 5; i++) {
        s = s + i;
    }
    for (int j = 0; j < 3; j++)
        s = s + j;
    return s;
}
