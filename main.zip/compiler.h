/* shared by compiler.y, opt.c and codegen.c */

extern char code[200][60];   /* three-address code: code[i] = line i, e.g. "t1 = a + b" */
extern int  n;               /* number of lines */

void optimize();
void codegen();
