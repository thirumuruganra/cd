int a, b;
a = 3 + 5 ^ 2;
b = 2 ^ 3 ^ 2 * a;
b = -a ^ b;
